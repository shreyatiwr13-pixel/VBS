//MANAGER

//signup ka code:

package com.vbs.demo.controller;

import com.vbs.demo.dto.DisplayDto;
import com.vbs.demo.dto.LoginDto;
import com.vbs.demo.dto.UpdateDto;
import com.vbs.demo.models.User;
import com.vbs.demo.repositories.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
        //restcontroller batayega manager hai

@CrossOrigin(origins ="*")
        //alag alag port sharing allowed nhi hota, sab data share nhi kar sakte, allow karne ke liye @cross origin/ to connect data bet frontend and backend

public class UserController {

    @Autowired
        //majdur(interface) ka object nhi bana sakte but banana padega isiliye autowired

    UserRepo userRepo;
            //majdur ka obj
            //manager ko samjha post aaya hai register ke upar-means majdur ko bolna hai save kar-needs majdur ka access- therefore majdur ka obj banao (1st is classname 2nd is obj name)

    @PostMapping("/register")
             //postmapping se clear hua ki this is post, therefore manager activate hua and end point dekhna padega, yaha /register hai which is sighup ka end point so sirf vhi activate hoga baki kn, forntend me register likha hai therefore match hoke activate hoga



    //signup func is this: register
    public String register(@RequestBody User user) {
              //ye bana function-'register', String coz last me string return karna hai
              //data aane wala hai from request ka body-@RequestBody, isko save karna hai user ke class ka obj (4 log ka kholi)    User- classname   user-obj name

        userRepo.save(user);
                 //userRepo(majdur) ko bolenge save kar and usko pass karenge obj

        return "Signup Successful";


    }

    //login ka code:

    @PostMapping("/login")
    public String login(@RequestBody LoginDto u) {
        User user = userRepo.findByUsername(u.getUsername());

        if (user == null) {
            return "User not found";
        }

        if (!u.getPassword().equals(user.getPassword())) {
            return "Password incorrect";
        }

        if (!u.getRole().equals(user.getRole())) {
            return "Role incorrect";
        }
        return String.valueOf(user.getId()); //id return kiya

    }
   @GetMapping("/get-details/{id}") //get mapping hai yaha par
   public DisplayDto display(@PathVariable int id){ //diplay is the function
        User user= userRepo.findById(id).orElseThrow(()->new RuntimeException("user not found"));
        DisplayDto displayDto= new DisplayDto();
        displayDto.setBalance(user.getBalance());
        displayDto.setUsername(user.getUsername());
        return displayDto;
   }


   @PostMapping("/update")
    public String update(@RequestBody UpdateDto obj){
        User user= userRepo.findById(obj.getId()).orElseThrow(()->new RuntimeException("Not found"));

        if (obj.getKey().equalsIgnoreCase("name"))
       {
           if (user.getName().equalsIgnoreCase(obj.getValue())) return "Cannot be same";
           user.setName(obj.getValue());
       }

       else if (obj.getKey().equalsIgnoreCase("password"))
       {
           if (user.getPassword().equalsIgnoreCase(obj.getValue())) return "Cannot be same";
           user.setPassword(obj.getValue());
       }

        else  if(obj.getKey().equalsIgnoreCase("Email")) {
            if (user.getEmail().equalsIgnoreCase(obj.getValue())) return "Cannot be same";
            User user2 = userRepo.findByEmail(obj.getValue());
            if (user2 != null) return "Email already exists";
            user.setEmail(obj.getValue());
        }
       else {
           return "Invalid key";
       }
       userRepo.save(user);
       return "Update done successfully";
    }


    @PostMapping("/add")
    public String add(@RequestBody User user){
        userRepo.save(user);
        return "Successfully added";
    }
}

// code exited with 1 error- kill port coz ek port pe 2 kaam chal rhe- serach on google