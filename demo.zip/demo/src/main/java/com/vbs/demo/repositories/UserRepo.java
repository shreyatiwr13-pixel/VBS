//MAJDUR

package com.vbs.demo.repositories;

import com.vbs.demo.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
        //batana padega ye repository hai

public interface UserRepo extends JpaRepository<User, Integer> {
         //JpaRepository ke pass sql queries hai, isko 2 chiz chahiye to make change in database- User is table ka naam and integer is PRIMARY KEY ka data type

    User findByUsername(String username);

    User findByEmail(String value);
}

    //ye majdur(interface) ko sql ka acces dena pdega therefore extends JpaRepo- usko 2 chiz denge i.e user,integer

